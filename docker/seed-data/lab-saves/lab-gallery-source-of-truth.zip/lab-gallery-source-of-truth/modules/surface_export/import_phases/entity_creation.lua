local Deserializer = require("modules/surface_export/core/deserializer")
local Util = require("modules/surface_export/utils/util")
local EntityCreation = {}

-- TEST-ONLY helper: does this serialized entity carry inventory items? The one-shot
-- `test_force_entity_failure` hook targets such an entity (a container/crafter with stable
-- counts) rather than a belt, so the failed-entity-loss attribution is exercised cleanly.
local function carries_inventory_items(entity_data)
  local sd = entity_data.specific_data
  if not sd or not sd.inventories then return false end
  for _, inv in ipairs(sd.inventories) do
    if inv.items and #inv.items > 0 then return true end
  end
  return false
end

local function carries_fluids(entity_data)
  local sd = entity_data.specific_data
  if not sd or not sd.fluids then return false end
  for _, fluid in ipairs(sd.fluids) do
    if (fluid.amount or 0) > 0 then return true end
  end
  return false
end

--- Process a batch of entity creation
--- @param job table: The import job state
--- @param get_batch_size function: Function to get current batch size
--- @param should_show_progress function: Function to check if progress should be shown
--- @return boolean: true if job is complete for this tick (either finished or batch reached)
function EntityCreation.process_batch(job, get_batch_size, should_show_progress)
    local batch_size = get_batch_size()
    local start_index = job.current_index + 1
    local end_index = math.min(start_index + batch_size - 1, job.total_entities)
    
    local batch_created = 0
    local batch_failed = 0
    local batch_skipped = 0
    
    for i = start_index, end_index do
      local entity_data = job.entities_to_create[i]
      if entity_data then
        if entity_data._beacon_placed then
          -- Already created by the beacon pre-placement phase; skip to avoid duplicates.
          -- The entity is already in entity_map under entity_data.entity_id.
          batch_created = batch_created + 1
        elseif entity_data.type == "item-on-ground" then
          local created = Deserializer.create_ground_item(job.target_surface, entity_data)
          if created and created.valid then
            batch_created = batch_created + 1
          else
            -- Ground item could not be placed (tile now occupied, invalid item, etc.) — tally as a
            -- loss so it is accounted (subtracted from expected) rather than silently dropped.
            batch_failed = batch_failed + 1
            local losses = job.failed_entity_losses
            if not losses then
              losses = { entity_count = 0, total_items = 0, total_fluids = 0.0, items = {}, fluids = {}, entities = {} }
              job.failed_entity_losses = losses
            end
            local item_key = Util.make_quality_key(entity_data.name, entity_data.quality or Util.QUALITY_NORMAL)
            losses.items[item_key] = (losses.items[item_key] or 0) + (entity_data.count or 0)
            losses.total_items = losses.total_items + (entity_data.count or 0)
            losses.entity_count = losses.entity_count + 1
            log(string.format("[Entity Creation] FAILED to place ground item '%s' x%d at (%.1f,%.1f) -- tallied as loss",
              entity_data.name, entity_data.count or 0, entity_data.position.x, entity_data.position.y))
          end
        else
          local entity
          -- TEST HOOK (one-shot, debug-gated): simulate a failed placement for the first
          -- inventory-bearing entity, exercising failed-entity-loss attribution + the expected-count
          -- subtraction so validation still passes (Pitfall #20). Set via
          -- configure({ test_force_entity_failure = true }).
          local _cfg = storage.surface_export_config
          local failure_mode = _cfg and _cfg.test_force_entity_failure
          local fluid_target = type(failure_mode) == "string"
            and string.match(failure_mode, "^inventory_and_fluid:(.+)$") or nil
          local fluid_x, fluid_y = nil, nil
          if type(failure_mode) == "string" then
            fluid_x, fluid_y = string.match(failure_mode, "^inventory_and_fluid_at:([^:]+):([^:]+)$")
          end
          local position_matches = fluid_x and fluid_y and entity_data.position
            and math.abs((entity_data.position.x or entity_data.position[1]) - tonumber(fluid_x)) < 0.001
            and math.abs((entity_data.position.y or entity_data.position[2]) - tonumber(fluid_y)) < 0.001
          -- An armed string mode that parses to NEITHER pattern can never match any entity:
          -- warn once per job instead of leaving the flag silently armed forever.
          if type(failure_mode) == "string" and not fluid_target and not fluid_x
              and not job.warned_unrecognized_failure_mode then
            job.warned_unrecognized_failure_mode = true
            log(string.format("[TEST HOOK] WARNING: test_force_entity_failure=%q matches no known pattern (inventory_and_fluid:<name> | inventory_and_fluid_at:<x>:<y> | true) — hook stays armed but will never fire", failure_mode))
          end
          local matches_failure_mode = (fluid_target ~= nil
            and entity_data.name == fluid_target
            or position_matches)
            and carries_inventory_items(entity_data) and carries_fluids(entity_data)
            or failure_mode == true and carries_inventory_items(entity_data)
          if _cfg and _cfg.debug_mode and matches_failure_mode
              and entity_data.name ~= "space-platform-hub" then
            _cfg.test_force_entity_failure = nil  -- consume: applies to one entity only
            job.test_forced_entity_failure = true
            entity = nil
            log(string.format("[TEST HOOK] Forcing placement failure for %s entity '%s' to exercise failed-entity-loss attribution",
              tostring(failure_mode), entity_data.name))
          else
            entity = Deserializer.create_entity(job.target_surface, entity_data)
          end
          if entity and entity.valid then
            batch_created = batch_created + 1
            -- Store in entity_map for post-processing (circuit connections, etc.)
            if entity_data.entity_id then
              job.entity_map[entity_data.entity_id] = entity
            end
            
            -- CRITICAL: If this is a transfer, deactivate productive entities BEFORE restoring state/inventories.
            -- This prevents crafting machines from consuming items the moment a recipe is set.
            -- Passive entities (beacons, radars, walls) are excluded — they hold no items/fluids
            -- and must remain active so beacon speed bonuses apply to nearby machines as they are placed.
            -- item-request-proxy joins the exclusions (review F1, 2026-07-19): proxies consume
            -- nothing, and they are absent from ACTIVATABLE_ENTITY_TYPES so a deactivated proxy
            -- would NEVER be reactivated — arriving permanently inert.
            if job.transfer_id and entity.type ~= "beacon" and entity.type ~= "radar"
                and entity.type ~= "item-request-proxy" then
              local ok, err = pcall(function()
                if entity.active then
                  entity.active = false
                end
              end)
              if not ok then
                log(string.format("[Import] Failed to deactivate entity %s: %s", entity.name, tostring(err)))
              end
            end
            
            -- Now safely restore state with entity deactivated
            -- NOTE: Fluids are restored in post-processing phase (complete_import_job)
            -- This is CRITICAL because restoring fluids immediately causes fluid network
            -- redistribution when connected pipes/tanks are created later in the batch
            -- NOTE: Inventories are also restored in post-processing phase (complete_import_job)
            -- This is CRITICAL because set_stack() ceiling depends on crafting_speed, which
            -- depends on beacon effects. Beacons may not yet be placed when an entity is created
            -- in an earlier batch — restoring inventories here would lose items to a too-low cap.
            Deserializer.restore_entity_state(entity, entity_data)
          else
            -- space-platform-hub returns nil from create_entity deliberately:
            -- it is pre-created with the platform and mapped in platform_hub_mapping.
            -- Its inventories ARE restored there, so do NOT count it as lost here.
            if entity_data.name == "space-platform-hub" then
              batch_skipped = batch_skipped + 1
            else
              batch_failed = batch_failed + 1

              -- Tally items/fluids lost due to failed placement
              local losses = job.failed_entity_losses
              if not losses then
                losses = { entity_count = 0, total_items = 0, total_fluids = 0.0, items = {}, fluids = {}, entities = {} }
                job.failed_entity_losses = losses
              end

              local entity_items = 0
              local entity_fluids = 0.0

              if entity_data.specific_data then
                -- Inventory items
                if entity_data.specific_data.inventories then
                  for _, inv_data in ipairs(entity_data.specific_data.inventories) do
                    for _, item in ipairs(inv_data.items or {}) do
                      local item_key = Util.make_quality_key(item.name, item.quality or Util.QUALITY_NORMAL)
                      losses.items[item_key] = (losses.items[item_key] or 0) + item.count
                      entity_items = entity_items + item.count
                    end
                  end
                end
                -- Belt items
                if entity_data.specific_data.items then
                  for _, line_data in ipairs(entity_data.specific_data.items) do
                    for _, item in ipairs(line_data.items or {}) do
                      local item_key = Util.make_quality_key(item.name, item.quality or Util.QUALITY_NORMAL)
                      losses.items[item_key] = (losses.items[item_key] or 0) + item.count
                      entity_items = entity_items + item.count
                    end
                  end
                end
                -- Inserter held item
                if entity_data.specific_data.held_item then
                  local held = entity_data.specific_data.held_item
                  local item_key = Util.make_quality_key(held.name, held.quality or Util.QUALITY_NORMAL)
                  losses.items[item_key] = (losses.items[item_key] or 0) + held.count
                  entity_items = entity_items + held.count
                end
                -- Fluids
                if entity_data.specific_data.fluids then
                  for _, fluid_data in ipairs(entity_data.specific_data.fluids) do
                    local key = fluid_data.name
                    losses.fluids[key] = (losses.fluids[key] or 0.0) + (fluid_data.amount or 0)
                    entity_fluids = entity_fluids + (fluid_data.amount or 0)
                  end
                end
              end

              losses.entity_count = losses.entity_count + 1
              losses.total_items = losses.total_items + entity_items
              losses.total_fluids = losses.total_fluids + entity_fluids

              -- Cap detail entries to avoid memory bloat
              if #losses.entities < 50 then
                table.insert(losses.entities, {
                  name = entity_data.name or "?",
                  type = entity_data.type or "?",
                  position = entity_data.position,
                  items = entity_items,
                  fluids = entity_fluids,
                })
              end

              log(string.format("[Entity Creation] FAILED to create '%s' (type=%s) at (%.1f,%.1f) — lost %d items, %.1f fluids — index %d/%d",
                entity_data.name or "?", entity_data.type or "?",
                entity_data.position and (entity_data.position.x or entity_data.position[1]) or 0,
                entity_data.position and (entity_data.position.y or entity_data.position[2]) or 0,
                entity_items, entity_fluids, i, job.total_entities))
            end
          end
        end
      else
        batch_skipped = batch_skipped + 1
      end
    end
    
    job.current_index = end_index
    
    -- Log batch summary (every batch for first 5 and every 10th after)
    local batch_num = math.floor(end_index / batch_size)
    if batch_num <= 5 or batch_num % 10 == 0 or end_index >= job.total_entities then
      log(string.format("[Entity Creation] Batch %d: entities %d-%d/%d, created=%d, failed=%d, skipped=%d (job=%s)",
        batch_num, start_index, end_index, job.total_entities,
        batch_created, batch_failed, batch_skipped, job.job_id))
    end
    
    -- Show progress every 10 batches
    if should_show_progress() and end_index % (batch_size * 10) == 0 then
      local progress = math.floor((end_index / job.total_entities) * 100)
      game.print(string.format("[Import %s] Progress: %d%% (%d/%d entities)",
        job.platform_name, progress, end_index, job.total_entities))
    end
    
    return job.current_index >= job.total_entities
end

return EntityCreation
