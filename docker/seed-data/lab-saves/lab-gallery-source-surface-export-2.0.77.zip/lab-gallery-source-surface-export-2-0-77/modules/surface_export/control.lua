-- Surface Export Clusterio Module (Save-patched)
-- Integrates FactorioSurfaceExport with Clusterio for cross-instance platform transfers
--
-- IMPORTANT: This module uses the event_handler interface required by Clusterio.
-- Do NOT use script.on_init, script.on_event, etc. directly — that would
-- overwrite Clusterio's own event handlers and break initialization.
-- See: https://github.com/clusterio/clusterio/blob/main/docs/developing-for-clusterio.md

local clusterio_api = require("modules/clusterio/api")

-- Import existing functionality
local RemoteInterface = require("modules/surface_export/interfaces/remote-interface")
local Commands = require("modules/surface_export/interfaces/commands")
local AsyncProcessor = require("modules/surface_export/core/async-processor")
local SurfaceLock = require("modules/surface_export/utils/surface-lock")
local TransactionDashboard = require("modules/surface_export/interfaces/gui/transaction-dashboard")
local GatewayTransferGui = require("modules/surface_export/interfaces/gui/gateway-transfer")
local SelectionLab = require("modules/surface_export/interfaces/gui/selection-lab")
local Gateway = require("modules/surface_export/core/gateway")
local GameUtils = require("modules/surface_export/utils/game-utils")

-- Top-level module table (event_handler interface)
local SurfaceExportModule = {}

-- ============================================================================
-- Initialization (event_handler callbacks)
-- ============================================================================

local function initialize_storage()
	storage.platform_exports = storage.platform_exports or {}
	storage.pending_platform_imports = storage.pending_platform_imports or {}
	storage.surface_export = storage.surface_export or {}
	storage.surface_export_config = storage.surface_export_config or { debug_mode = true }
	storage.surface_export_config.gateways = storage.surface_export_config.gateways or {}
	storage.platform_flight_data = storage.platform_flight_data or {}
	AsyncProcessor.init()
end

function SurfaceExportModule.on_init()
	initialize_storage()
	log("[Surface Export] Save-patched module loaded with Clusterio support")
end

function SurfaceExportModule.on_load()
	-- Restore any necessary state (cannot modify global here in Factorio 2.0)
end

function SurfaceExportModule.on_configuration_changed(data)
	initialize_storage()
	-- Migrate any legacy name-keyed locks to index keys (cheap no-op once index-keyed). Also runs lazily at
	-- SurfaceLock.lock_platform so a deploy that didn't fire this hook still migrates before the next lock.
	SurfaceLock.ensure_index_keyed()
	-- Unlock gateways here too so adding the surfexp_gateways mod mid-save makes them routable
	-- without waiting for the next server startup.
	Gateway.discover_and_unlock()
	log("[Surface Export] Configuration changed - module state initialized")
end

-- ============================================================================
-- Remote Interface & Commands Registration
-- (add_remote_interface is called before on_init/on_load per event_handler)
-- ============================================================================

function SurfaceExportModule.add_remote_interface()
	RemoteInterface.register()
end

function SurfaceExportModule.add_commands()
	Commands.register()
end

-- ============================================================================
-- Event Handlers (event_handler interface)
-- ============================================================================

local e = defines.events

SurfaceExportModule.events = {
	-- Process async import/export jobs every tick
	[e.on_tick] = function()
		AsyncProcessor.process_tick()
		if game.tick % 60 == 0 then
			SurfaceLock.scan_transfer_expiries()
		end
	end,

	-- Clusterio custom events
	[clusterio_api.events.on_server_startup] = function()
		initialize_storage()
		-- Unlock gateway space-locations on every startup (covers every save load). Caches nothing.
		Gateway.discover_and_unlock()
		log("[Surface Export] Connected to Clusterio controller")
	end,

	[clusterio_api.events.on_instance_updated] = function()
		log("[Surface Export] Instance configuration updated")
	end,

	[e.on_space_platform_changed_state] = function(event)
		local platform = event.platform
		if not (platform and platform.valid) then return end

		-- CRITICAL: Space platforms use defines.space_platform_state, NOT defines.train_state
		local sps = defines.space_platform_state

		-- Track flight start time and estimated duration; clear on arrival
		storage.platform_flight_data = storage.platform_flight_data or {}
		if platform.state == sps.on_the_path then
			local est_ticks = nil
			local ok, result = pcall(function()
				local src = platform.space_location
				-- Read destination from schedule (platform.current_target does NOT exist)
				local schedule = platform.schedule
				local tgt_name = nil
				if schedule and schedule.records and schedule.current then
					tgt_name = schedule.records[schedule.current].station
				end
				if src and tgt_name and platform.speed and platform.speed > 0 then
					local tgt = game.space_location_prototypes[tgt_name]
					if tgt then
						return math.floor(math.abs((tgt.distance or 0) - (src.distance or 0)) / platform.speed)
					end
				end
			end)
			if ok then
				est_ticks = result
			else
				log(string.format("[Surface Export] ERROR computing flight duration estimate for '%s': %s",
					tostring(platform.name), tostring(result)))
			end
			storage.platform_flight_data[platform.name] = {
				departure_tick = game.tick,
				estimated_duration_ticks = est_ticks,
			}
		elseif platform.state == sps.waiting_at_station then
			storage.platform_flight_data[platform.name] = nil

			-- Gateway arrival detection: did the platform just park at a gateway? Detect + log, and (if the
			-- gateway has configured destinations) open the on-arrival chooser GUI for everyone VIEWING this
			-- platform. The arrival itself NEVER fires a transfer — that is the player's explicit Transfer
			-- click inside the GUI (a separate tick, outside this state-change). Uses the shared predicate.
			local gw_name = Gateway.parked_at_gateway(platform)
			if gw_name then
				log(string.format("[Gateway] Platform '%s' (force '%s') arrived at gateway '%s'",
					tostring(platform.name),
					tostring(platform.force and platform.force.name or "?"),
					gw_name))

				local cfg = Gateway.get_gateway_config(gw_name)
				if cfg and cfg.targets and #cfg.targets > 0 then
					local surf_idx = platform.surface.index
					for _, player in pairs(game.connected_players) do
						-- intentional probe; a surface_index read failure just means this player doesn't get
						-- the arrival chooser (no state/data impact), and the GUI-open below is itself
						-- pcall_warn-logged — so skipping silently here is the correct, harmless fallback.
						local ok, si = pcall(function() return player.surface_index end)
						if ok and si == surf_idx then
							GameUtils.pcall_warn("[Gateway] open arrival chooser", function()
								GatewayTransferGui.open(player, platform, gw_name)
							end)
						end
					end
				end
			end
		end

		-- Notify the controller so it can push a tree refresh to web subscribers
		if not (clusterio_api and clusterio_api.send_json) then return end
		GameUtils.pcall_warn("[Surface Export] send_json surface_platform_state_changed", function()
			clusterio_api.send_json("surface_platform_state_changed", {
				platform_name = platform.name,
				force_name = platform.force and platform.force.name or "player",
			})
		end)
	end,

	-- GUI events — routed to every plugin GUI; each acts only on its own elements.
	[e.on_gui_click] = function(event)
		TransactionDashboard.on_gui_click(event)
		GatewayTransferGui.on_gui_click(event)
	end,

	[e.on_gui_closed] = function(event)
		TransactionDashboard.on_gui_closed(event)
		GatewayTransferGui.on_gui_closed(event)
	end,

	-- Selection Lab (debug instrument; prototype ships in the surfexp_gateways mod, all logic here).
	-- Each handler self-guards on event.item == "selection-lab-tool" and debug_mode.
	[e.on_player_selected_area] = function(event)
		SelectionLab.handle(event, "copy")
	end,

	[e.on_player_alt_selected_area] = function(event)
		SelectionLab.handle(event, "paste")
	end,

	[e.on_player_reverse_selected_area] = function(event)
		SelectionLab.handle(event, "audit")
	end,

	[e.on_player_alt_reverse_selected_area] = function(event)
		SelectionLab.handle(event, "force")
	end,

	-- Selection Lab undo/redo (custom-input prototypes from the surfexp_gateways mod; string keys
	-- pass through the event_handler to script.on_event, which accepts custom-input names).
	["selection-lab-undo"] = function(event)
		SelectionLab.undo(event)
	end,

	["selection-lab-redo"] = function(event)
		SelectionLab.redo(event)
	end,
}

-- ============================================================================
-- API Documentation
-- ============================================================================

-- The remote interface "surface_export" provides these key functions:
--
-- For exports:
--   remote.call("surface_export", "export_platform", platform_index, force_name)
--   remote.call("surface_export", "export_platform_to_file", platform_index, force_name, filename)
--   remote.call("surface_export", "get_export", export_id)
--   remote.call("surface_export", "get_export_json", export_id)  -- JSON string for RCON
--   remote.call("surface_export", "list_exports")
--   remote.call("surface_export", "list_exports_json")  -- JSON string for RCON
--   remote.call("surface_export", "clear_old_exports", max_to_keep)
--
-- For imports (chunked RCON — Factorio 2.0 cannot read files at runtime):
--   remote.call("surface_export", "import_platform_chunk", platform_name, chunk_data, chunk_num, total_chunks, force_name)
--
-- For platform locking (transfer workflow):
--   remote.call("surface_export", "lock_platform_for_transfer", platform_index, force_name)
--   remote.call("surface_export", "unlock_platform", platform_index_or_name)  -- index preferred; name accepted
--
-- For validation:
--   remote.call("surface_export", "get_validation_result", platform_name)
--   remote.call("surface_export", "get_validation_result_json", platform_name)
--
-- Configuration:
--   remote.call("surface_export", "configure", config_table)
--
-- Debug/testing:
--   remote.call("surface_export", "test_import_entity", entity_json, surface_index, position)
--   remote.call("surface_export", "run_tests")
--   remote.call("surface_export", "clone_platform", source_index, dest_name)  -- source by UNIQUE per-force index, 2 args

return SurfaceExportModule
