local sprites = data.raw["utility-sprites"] and data.raw["utility-sprites"].default
if not sprites then return end

sprites.starmap_star = {
	type = "sprite",
	filename = "__surfexp_gateways__/graphics/icons/starmap-clear.png",
	priority = "extra-high-no-scale",
	size = 64,
	flags = {"gui-icon"},
}
