-- Auto generated scenario module loader created by Clusterio
-- Modifications to this file will be lost when loaded in Clusterio
clusterio_patch_number = 2

local event_handler = require("event_handler")

-- Scenario modules
require("scenario")

-- Clusterio modules
event_handler.add_lib(require("modules/clusterio/impl"))
event_handler.add_lib(require("modules/clusterio/compat"))
event_handler.add_lib(require("modules/surface_export/control"))
require("modules/statistics_exporter/export")
